package pageActions;

import pageObjects.LoginPageObjects;
import utilities.Utilities;

public class LoginPageActions {

	LoginPageObjects loginObj;
	Utilities utils;

	public void enterEmailId(String emailId) {
		loginObj = new LoginPageObjects();
		loginObj.loginEmail.sendKeys(emailId);
	}
	
	public void enterPassword(String password) {
		//loginObj = new LoginPageObjects();
		loginObj.loginPassword.sendKeys(password);
	}
	
	public void clickOnLoginButton() {
		//loginObj = new LoginPageObjects();
				loginObj.loginButton.click();
	}
}