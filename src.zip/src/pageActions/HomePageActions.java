package pageActions;

import pageObjects.HomePageObjects;

public class HomePageActions{
	
	public String getUsersNameText() {
		HomePageObjects homePageObj = new HomePageObjects();
		String userName = homePageObj.usersNameText.getText();
		return userName;
	}
}