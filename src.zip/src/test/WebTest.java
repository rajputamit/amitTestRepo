package test;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageActions.HomePageActions;
import pageActions.LoginPageActions;
import utilities.EnvironmentSetup;
import utilities.Utilities;

public class WebTest extends EnvironmentSetup {

	@Test(priority = 1, description = "get page title and verify")
	public void verifyLoginPageTitle() {
		String pageTitle = driver.getTitle();
		Assert.assertEquals(pageTitle, "Facebook � log in or sign up");
	}

	@Test(priority = 2, description = "verifying login to facebook")
	public void loginToFb() {
		LoginPageActions loginActions = new LoginPageActions();
		Utilities utils = new Utilities();
		String emailId = utils.readProperties("loginPageObjectValues", "email");
		String password = utils.readProperties("loginPageObjectValues", "password");

		loginActions.enterEmailId(emailId);
		loginActions.enterPassword(password);
		loginActions.clickOnLoginButton();

		HomePageActions homeActions = new HomePageActions();
		String userNameText = homeActions.getUsersNameText();

		Assert.assertEquals(userNameText, "Amit Rajput");

	}
}