package utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Properties;

public class Utilities {

	public String readProperties(String fileName, String key) {
		String value = "";
		try {
			File file = new File(
					System.getProperty("user.dir") + "\\TestData\\Properties\\" + fileName + ".properties");
			FileReader fr = new FileReader(file);
			Properties prop = new Properties();
			prop.load(fr);
			value = prop.getProperty(key);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return value;
	}
}