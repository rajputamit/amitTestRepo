package utilities;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

public class EnvironmentSetup {

	public static WebDriver driver;
	private DesiredCapabilities caps;

	@BeforeSuite
	public WebDriver initDriver() {
		try {
			Utilities util = new Utilities();
			String selectedBrowser = util.readProperties("configuration", "browserName");
			String selectedAppUrl = util.readProperties("configuration", "appUrl");
			System.out.println("Selecting browser is: " + selectedBrowser);
			switch (selectedBrowser) {
			case "MF":
				System.setProperty("webdriver.gecko.driver",
						System.getProperty("user.dir") + "\\Executables\\geckodriver.exe");
				caps = new DesiredCapabilities();
				caps.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				
				/*ProfilesIni profile = new ProfilesIni();
				FirefoxProfile myprofile = profile.getProfile("testProf");
				*/
				driver = new FirefoxDriver(caps);
				//driver.manage().window().maximize();
				driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
				driver.manage().deleteAllCookies();
				driver.get(selectedAppUrl);
				System.out.println(driver.getTitle());
				//driver.quit();
				break;

			case "GC":
				System.setProperty("webdriver.chrome.driver",
						System.getProperty("user.dir") + "\\Executables\\chromedriver.exe");
				/*caps = new DesiredCapabilities();
				caps.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				*/
				ChromeOptions chromeOptions = new ChromeOptions();
				chromeOptions.addArguments("--start-maximized");
				driver = new ChromeDriver(chromeOptions);
				
				//driver.manage().window().maximize();
				driver.get(selectedAppUrl);
				System.out.println(driver.getTitle());
				//driver.quit();
				break;

			case "IE":
				System.setProperty("webdriver.ie.driver",
						System.getProperty("user.dir") + "\\Executables\\IEDriverServer.exe");
				caps = new DesiredCapabilities();
				caps.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				driver = new InternetExplorerDriver(caps);
				driver.manage().window().maximize();
				driver.get(selectedAppUrl);
				System.out.println(driver.getTitle());
				//driver.quit();
				break;

			default:
				System.setProperty("webdriver.gecko.driver",
						System.getProperty("user.dir") + "\\Executables\\geckodriver.exe");
				caps = new DesiredCapabilities();
				caps.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				driver = new FirefoxDriver(caps);
				driver.manage().window().maximize();
				driver.get(selectedAppUrl);
				System.out.println(driver.getTitle());
				//driver.quit();
				break;
			}

		} catch (Exception e) {
			// TODO: handle exception
		}
		return driver;
	}
	
	@AfterSuite
	public void tearDown() {
		driver.quit();
	}
}