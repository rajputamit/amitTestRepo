package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utilities.EnvironmentSetup;

public class HomePageObjects extends EnvironmentSetup {

	public HomePageObjects() {
		PageFactory.initElements(driver, this);
		// return driver;
	}

	@FindBy(xpath = "//*[@id='userNav']//a/div[@dir='ltr']")
	public WebElement usersNameText;
}