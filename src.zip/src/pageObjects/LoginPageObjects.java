package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utilities.EnvironmentSetup;

public class LoginPageObjects extends EnvironmentSetup{
	
	public LoginPageObjects() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id="email")
	public WebElement loginEmail;
	
	@FindBy(id="pass")
	public WebElement loginPassword;
	
	@FindBy(xpath="//*[@id='loginbutton']/input")
	public WebElement loginButton;

}